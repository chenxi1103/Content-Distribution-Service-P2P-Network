public class router {
    int node;
    int distance;
    public router() {

    }
    router(int node, int distance) {
        this.node = node;
        this.distance = distance;
    }
}
